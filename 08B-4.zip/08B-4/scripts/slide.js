$(document).ready(function(){
    var pos = 1;
    setInterval(function(){
        $("#wrap .sec_b .slide").css({
            'margin-left':-pos*100+'%'
        })
        pos++;
        if(pos == 3) {pos=0}
    },2500)
})